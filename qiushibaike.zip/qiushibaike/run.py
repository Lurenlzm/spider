# coding:utf-8
from scrapy import cmdline
def updata():
	cmdline.execute("scrapy crawl Csbk".split())
	return 0
if __name__ == '__main__':
	updata()

